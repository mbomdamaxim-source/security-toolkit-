from core import elevation


def test_non_windows_is_not_treated_as_administrator(monkeypatch):
    monkeypatch.setattr(elevation.os, "name", "posix")
    assert elevation.is_administrator() is False


def test_failed_relaunch_does_not_exit(monkeypatch):
    monkeypatch.setattr(elevation, "relaunch_as_administrator", lambda: False)
    exits = []
    assert elevation.request_relaunch_and_exit(exits.append) is False
    assert exits == []


def test_successful_relaunch_exits_current_process(monkeypatch):
    monkeypatch.setattr(elevation, "relaunch_as_administrator", lambda: True)
    exits = []
    assert elevation.request_relaunch_and_exit(exits.append) is True
    assert exits == [0]
