from collections import Counter
import pytest
from core.quiz_history import QuizHistory
from modules.subnet.logic import QUIZ_BANK, QuizSession, allocate_vlsm, cidr_to_mask, quiz_choices, verify_quiz_bank

def test_fixed_bank_has_90_independently_verified_answers():
    verify_quiz_bank(); assert len(QUIZ_BANK) == 90
    assert Counter(q.question_type for q in QUIZ_BANK) == {'subnet_membership':15,'broadcast_address':15,'usable_hosts':15,'cidr_to_mask':15,'first_usable_host':7,'last_usable_host':8,'wildcard_mask':15}
def test_quiz_session_shuffles_without_repeats():
    session=QuizSession(); seen=[]
    while not session.complete: seen.append(session.current.identifier); session.submit(session.current.correct_answer)
    assert len(seen)==len(set(seen))==90
def test_cidr_conversion(): assert cidr_to_mask('/18')=='255.255.192.0'

def test_vlsm_verified_example_matches_expected_allocation():
    rows = allocate_vlsm("192.168.10.0/24", [("Users", 100), ("Servers", 50), ("Management", 20)])
    assert [(r["name"], r["network"], r["cidr"], r["broadcast"]) for r in rows] == [
        ("Users", "192.168.10.0", "/25", "192.168.10.127"),
        ("Servers", "192.168.10.128", "/26", "192.168.10.191"),
        ("Management", "192.168.10.192", "/27", "192.168.10.223"),
    ]

def test_vlsm_sorts_largest_requirement_first():
    rows = allocate_vlsm("10.0.0.0/24", [("Small", 2), ("Big", 100)])
    assert rows[0]["name"] == "Big" and rows[0]["cidr"] == "/25"

def test_vlsm_rejects_requirements_that_do_not_fit():
    with pytest.raises(ValueError, match="does not fit"):
        allocate_vlsm("10.0.0.0/24", [("A", 300)])
    with pytest.raises(ValueError, match="does not fit"):
        allocate_vlsm("10.0.0.0/23", [("A", 300), ("B", 200)])

def test_vlsm_validates_inputs():
    with pytest.raises(ValueError): allocate_vlsm("not-an-ip", [("A", 2)])
    with pytest.raises(ValueError): allocate_vlsm("10.0.0.0/24", [("", 2)])
    with pytest.raises(ValueError): allocate_vlsm("10.0.0.0/24", [("A", 0)])
    with pytest.raises(ValueError): allocate_vlsm("10.0.0.0/24", [("A", 2), ("a", 2)])
    with pytest.raises(ValueError): allocate_vlsm("10.0.0.0/24", [])

def test_vlsm_smallest_block_is_slash_30():
    rows = allocate_vlsm("10.0.0.0/30", [("P2P", 2)])
    assert rows[0]["cidr"] == "/30" and rows[0]["usable_range"] == "10.0.0.1 – 10.0.0.2"

def test_quiz_choices_always_four_distinct_options_including_answer():
    for question in QUIZ_BANK:
        options = quiz_choices(question.correct_answer, rng=__import__("random").Random(7))
        assert len(options) == 4 and len(set(options)) == 4
        assert question.correct_answer in options
        assert not any("Option " in option for option in options)

def test_quiz_choices_ip_answer_with_colliding_fixed_pool():
    # Regression: "255.255.255.0" collided with the old fixed alternative pool
    # and produced a bogus "Option 4" decoy.
    options = quiz_choices("255.255.255.0", rng=__import__("random").Random(7))
    assert len(options) == 4 and len(set(options)) == 4 and "255.255.255.0" in options

def _entry(index=1):
    return {"date": "2026-08-29", "category": "Usable hosts", "mode": "Practice", "score": index, "total": 15, "percentage": 7}

def test_quiz_history_records_and_caps_at_20(tmp_path):
    store = QuizHistory(tmp_path / "quiz_history.json")
    for index in range(25): store.record(_entry(index))
    entries = store.load()
    assert len(entries) == 20
    assert entries[0]["score"] == 24 and entries[-1]["score"] == 5
    assert store.path.exists()

def test_quiz_history_survives_corrupt_file(tmp_path):
    path = tmp_path / "quiz_history.json"; path.write_text("{not valid json", encoding="utf-8")
    assert QuizHistory(path).load() == []

def test_quiz_history_rejects_malformed_entries(tmp_path):
    store = QuizHistory(tmp_path / "quiz_history.json")
    store.record(_entry())
    path = store.path; path.write_text('[{"date":"2026-08-29","category":"Usable hosts"},{"score":1,"total":15,"percentage":7,"mode":"Practice","date":"2026-08-29","category":"Usable hosts"}]', encoding="utf-8")
    entries = store.load()
    assert len(entries) == 1 and entries[0]["score"] == 1
