# Bastion

**Learn your system. Secure your system.**

Bastion is a Windows desktop application for improving the security posture of the Windows device on which it runs. It is not a remote-target scanning tool.

## Current development status

Block 0 (application shell: module navigation with a collapsible sidebar toggle, design system, Windows administrator-elevation status) and Block 1 (Subnet and VLSM: calculator, verified 90-question quiz with exam modes, report cards, review-missed and local history) are implemented. Block 2 (Credential Auditor: local-only password strength analysis with a 2,033-entry common-password bank, leet-variant detection, pattern-aware entropy and crack-time estimates, embedded-word and personal-context checks, and a secure password generator) is implemented in the native module and the browser preview, including a Crypto Lab overlay window (Caesar, Vigenere, Base64, SHA-256, AES-256-GCM, Caesar brute-force breaker, salted password hashing, and RSA key-pair demos with tamper detection) and an 80-question verified crypto quiz across 8 categories (10 questions each: symmetric vs asymmetric, hashing, TLS/HTTPS, classic ciphers, encoding vs encryption, key security, digital signatures, key exchange), each answer with a brief explanation, plus full quiz features matching the subnet quiz (practice and timed exam modes, progress bar, timer warnings, keyboard shortcuts, per-category performance report with review-missed and local history). Block 3 (Scan Reports: read-only local scan via PowerShell cmdlets - Get-NetTCPConnection/Get-NetUDPEndpoint/Get-Service/Get-HotFix/Get-NetFirewallRule - with firewall-aware port exposure classification, UDP listeners, active-connection heuristics, drift detection against the previous scan, an allowlist of expected listeners, a Word report export, and full visual summaries) is implemented in the native module and the browser preview. The remaining feature modules are placeholders until their scheduled development blocks.

Quiz-attempt summaries (subnet and crypto) are stored locally in `%LOCALAPPDATA%\Bastion\` (`quiz_history.json` and `crypto_quiz_history.json`, last 20 entries each). The files record only dates, categories, modes, and scores — never questions, answers, passwords, or other sensitive data.

## Run on Windows

Bastion is a PySide6 desktop application, so it does not run as a browser website or Arena live preview. Run it on a Windows computer with Python 3.11 or newer:

```powershell
cd path\to\security-toolkit-
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python app.py
```

To run the current tests:

```powershell
python -m pytest -q
```

The Firewall Builder, Scan Reports, and Traffic Dashboard will require administrator privileges when their real system-facing features are introduced. Do not run the application as administrator unless Windows requests elevation for a specific action.

## Linux development environments

The target platform is Windows. A Linux environment running PySide6 also needs its Qt/OpenGL system libraries installed by the operating system before the graphical application can start. This workspace is missing those libraries, so it can compile and run non-GUI tests but cannot display the desktop window.
