"""Bastion desktop application entry point."""
from __future__ import annotations

import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPainter, QPalette, QPen
from PySide6.QtWidgets import (
    QApplication, QHBoxLayout, QListWidget, QMainWindow, QSizePolicy,
    QStackedWidget, QToolButton, QVBoxLayout, QWidget,
)

from core import theme
from core.context import AppContext
from core.elevation import can_request_administrator_relaunch, is_administrator, request_relaunch_and_exit
from core.status_widgets import StatusBanner
from modules.credentials.ui import CredentialAuditorModule
from modules.firewall.ui import FirewallModule
from modules.scanner.ui import LocalScanModule
from modules.subnet.ui import SubnetModule
from modules.traffic.ui import TrafficModule


class SidebarToggle(QToolButton):
    """Icon button: shows a cross when the sidebar is open (click to close)
    and a hamburger when it is collapsed (click to open)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._sidebar_open = True
        self.setFixedSize(34, 34)
        self.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonIconOnly)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self._update_accessibility()

    def _update_accessibility(self):
        if self._sidebar_open:
            self.setAccessibleName("Collapse navigation")
            self.setToolTip("Collapse navigation")
        else:
            self.setAccessibleName("Expand navigation")
            self.setToolTip("Expand navigation")

    def set_sidebar_open(self, open_state: bool) -> None:
        self._sidebar_open = open_state
        self._update_accessibility()
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        pen = QPen(QColor(theme.COLOR_TEXT_SECONDARY), 2)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        width, height = self.width(), self.height()
        if self._sidebar_open:
            # cross - indicates the sidebar can be closed
            painter.drawLine(int(width * 0.3), int(height * 0.3), int(width * 0.7), int(height * 0.7))
            painter.drawLine(int(width * 0.7), int(height * 0.3), int(width * 0.3), int(height * 0.7))
        else:
            # hamburger - three aligned rows
            for fraction in (0.35, 0.5, 0.65):
                y = int(height * fraction)
                painter.drawLine(int(width * 0.22), y, int(width * 0.78), y)
        painter.end()


class MainWindow(QMainWindow):
    def __init__(self, context: AppContext):
        super().__init__()
        self.context = context
        self.setWindowTitle(f"{theme.APP_NAME} {context.app_version} — {theme.APP_TAGLINE}")
        self.resize(1120, 720)
        self._build_ui()

    def _build_ui(self) -> None:
        root = QWidget()
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(theme.SPACE_LG, theme.SPACE_LG, theme.SPACE_LG, theme.SPACE_LG)
        root_layout.setSpacing(theme.SPACE_MD)
        root_layout.addWidget(self._create_elevation_banner())

        header_layout = QHBoxLayout()
        header_layout.setSpacing(theme.SPACE_MD)
        self.sidebar_toggle = SidebarToggle()
        self.sidebar_toggle.clicked.connect(self._toggle_sidebar)
        header_layout.addWidget(self.sidebar_toggle)
        header_layout.addStretch(1)
        root_layout.addLayout(header_layout)

        content_layout = QHBoxLayout()
        content_layout.setSpacing(theme.SPACE_MD)
        self.navigation = QListWidget()
        self.navigation.setFixedWidth(210)
        self.navigation.setAccessibleName("Security module navigation")
        self.navigation.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        self.stack = QStackedWidget()
        self.stack.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        modules = [
            ("Subnet and VLSM", SubnetModule(self.context)),
            ("Credential Auditor", CredentialAuditorModule(self.context)),
            ("Scan Reports", LocalScanModule(self.context)),
            ("Firewall Builder", FirewallModule(self.context)),
            ("Traffic Dashboard", TrafficModule(self.context)),
        ]
        for label, module in modules:
            self.navigation.addItem(label)
            self.stack.addWidget(module)
        self.navigation.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.navigation.setCurrentRow(0)

        content_layout.addWidget(self.navigation)
        content_layout.addWidget(self.stack, 1)
        root_layout.addLayout(content_layout, 1)
        self.setCentralWidget(root)

    def _create_elevation_banner(self) -> StatusBanner:
        if self.context.is_admin:
            return StatusBanner(
                "Administrator privileges are active. System security actions are available.",
                "success",
            )
        banner = StatusBanner(
            "Administrator privileges are not active. Actions that change system security settings are unavailable.",
            "warning",
        )
        banner.add_action(
            "Restart with administrator privileges",
            self._restart_as_administrator,
            enabled=can_request_administrator_relaunch(),
        )
        return banner

    def _toggle_sidebar(self) -> None:
        collapsed = self.navigation.isHidden()
        self.navigation.setVisible(collapsed)
        self.sidebar_toggle.set_sidebar_open(collapsed)

    def _restart_as_administrator(self) -> None:
        if request_relaunch_and_exit():
            QApplication.quit()


def _create_dark_palette() -> QPalette:
    """Dark application palette so native Qt subcontrols (spin-box arrows,
    radio indicators, scroll-bar buttons, menu glyphs) draw dark instead of
    falling back to the light Windows default palette."""
    colors = {
        QPalette.ColorRole.Window: theme.COLOR_BACKGROUND,
        QPalette.ColorRole.WindowText: theme.COLOR_TEXT_PRIMARY,
        QPalette.ColorRole.Base: theme.COLOR_SURFACE,
        QPalette.ColorRole.AlternateBase: theme.COLOR_BACKGROUND,
        QPalette.ColorRole.Text: theme.COLOR_TEXT_PRIMARY,
        QPalette.ColorRole.Button: theme.COLOR_SURFACE_RAISED,
        QPalette.ColorRole.ButtonText: theme.COLOR_TEXT_PRIMARY,
        QPalette.ColorRole.BrightText: theme.COLOR_DANGER,
        QPalette.ColorRole.Highlight: theme.COLOR_ACCENT,
        QPalette.ColorRole.HighlightedText: theme.COLOR_BACKGROUND,
        QPalette.ColorRole.ToolTipBase: theme.COLOR_SURFACE_RAISED,
        QPalette.ColorRole.ToolTipText: theme.COLOR_TEXT_PRIMARY,
        QPalette.ColorRole.PlaceholderText: theme.COLOR_TEXT_SECONDARY,
        QPalette.ColorRole.Link: theme.COLOR_ACCENT,
    }
    palette = QPalette()
    for role, color in colors.items():
        palette.setColor(role, QColor(color))
    palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, QColor(theme.COLOR_TEXT_SECONDARY))
    palette.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, QColor(theme.COLOR_TEXT_SECONDARY))
    return palette


def create_application(argv: list[str] | None = None) -> QApplication:
    application = QApplication(argv if argv is not None else sys.argv)
    application.setApplicationName(theme.APP_NAME)
    application.setPalette(_create_dark_palette())
    application.setStyleSheet(theme.APPLICATION_STYLESHEET)
    return application


def main() -> int:
    application = create_application()
    context = AppContext(is_admin=is_administrator(), app_version=theme.APP_VERSION)
    window = MainWindow(context)
    window.show()
    return application.exec()


if __name__ == "__main__":
    sys.exit(main())
