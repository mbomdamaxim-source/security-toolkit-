from core.context import AppContext
from modules.placeholder import PlaceholderModule

class FirewallModule(PlaceholderModule):
    def __init__(self, context: AppContext):
        super().__init__(context, "Firewall Builder", "Create and manage validated Windows Defender Firewall rules.")
