from core.context import AppContext
from modules.placeholder import PlaceholderModule

class TrafficModule(PlaceholderModule):
    def __init__(self, context: AppContext):
        super().__init__(context, "Traffic Dashboard", "Observe this device's network activity and potential anomalies.")
